<?php

$text="The quick brown fox jumps over the lazy dog.";
echo strtolower("$text\n");
echo str_replace("brown","red","$text");

//echo strtolower(str_replace("brown","red","$text"));

?>